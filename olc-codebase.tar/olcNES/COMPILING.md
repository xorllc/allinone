g++ -lX11 -lGL -lpthread -lpng *.cpp -o out
